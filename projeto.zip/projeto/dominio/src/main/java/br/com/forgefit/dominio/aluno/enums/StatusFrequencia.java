package br.com.forgefit.dominio.aluno.enums;

public enum StatusFrequencia {
    PRESENTE,
    FALTA;
}