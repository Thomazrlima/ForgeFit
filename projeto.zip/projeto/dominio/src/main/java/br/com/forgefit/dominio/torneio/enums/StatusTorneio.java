package br.com.forgefit.dominio.torneio.enums;

public enum StatusTorneio {
    PLANEJADO,
    ATIVO,
    FINALIZADO,
    CANCELADO
}

