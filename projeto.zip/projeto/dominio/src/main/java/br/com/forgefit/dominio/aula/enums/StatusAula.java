package br.com.forgefit.dominio.aula.enums;

public enum StatusAula {
    ATIVA,
    CANCELADA
}
