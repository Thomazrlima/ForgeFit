package br.com.forgefit.dominio.torneio.enums;

public enum PosicaoDoPodio {
    PRIMEIRO_LUGAR,
    SEGUNDO_LUGAR,
    TERCEIRO_LUGAR
}

