package br.com.forgefit.dominio.ranking.enums;

public enum PeriodoRanking {
    SEMANAL,
    MENSAL,
    GERAL
}
