package br.com.forgefit.dominio.evento;

public interface EventoBarramento {
    void postar(Object evento);
}