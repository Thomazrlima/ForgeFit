package br.com.forgefit.dominio.aula.enums;

public enum Espaco {
    SALA01_MULTIUSO,
    SALA02_MULTIUSO,
    SALA03_SPINNING,
    ESTUDIO_PILATES,
    AREA_DE_LUTAS,
    AREA_DE_PESO_LIVRE
}
