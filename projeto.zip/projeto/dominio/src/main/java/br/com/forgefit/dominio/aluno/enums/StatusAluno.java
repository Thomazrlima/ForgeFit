package br.com.forgefit.dominio.aluno.enums;

public enum StatusAluno {
    ATIVO,
    BLOQUEADO;
}
