package br.com.forgefit.dominio.checkin.enums;

public enum TipoDeCheckin {
    AULA,
    TREINO
}

