package br.com.forgefit.dominio.treino.enums;

public enum LetraDoTreino {
    A, B, C, D, E, F, G
}

