package br.com.forgefit.dominio.aula.enums;

public enum StatusReserva {
    CONFIRMADA,
    CANCELADA_PELO_ALUNO,
    CANCELADA_PELA_ACADEMIA
}
