package br.com.forgefit.dominio.frequencia.enums;

/**
 * Status possíveis para o registro de frequência.
 */
public enum StatusFrequencia {
    PRESENCA,
    FALTA
}
