package br.com.forgefit.dominio.guilda.enums;

public enum StatusGuilda {
    ATIVA,
    INATIVA
}

