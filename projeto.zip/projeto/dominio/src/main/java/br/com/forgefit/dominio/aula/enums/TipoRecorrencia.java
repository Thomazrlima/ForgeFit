package br.com.forgefit.dominio.aula.enums;

public enum TipoRecorrencia {
    SEMANAL,
    MENSAL,
    SEMESTRAL,
    ANUAL
}
